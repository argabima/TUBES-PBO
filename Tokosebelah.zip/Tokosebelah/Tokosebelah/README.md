# Kasir
 Aplikasi Kasir Dengan Database Mysql Menggunakan Netbeans 8.0.1

Need Library :
 - rs2xml.jar

# Screenshot

![transaksi](https://user-images.githubusercontent.com/33270746/69935077-6cf1e280-1506-11ea-94f9-9039322bf45c.png)

![barang](https://user-images.githubusercontent.com/33270746/69935078-6d8a7900-1506-11ea-8834-4d2e1c5ad44f.png)

